<?php
/**
 * Include and setup custom metaboxes and fields. (make sure you copy this file to outside the FILETRIP_CMB directory)
 *
 * @category Filetrip
 * @package  Metaboxes
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/webdevstudios/Custom-Metaboxes-and-Fields-for-Word_press
 */

/**
 * Get the bootstrap! If using the plugin from wordpress.org, REMOVE THIS!
 */
if ( file_exists( FILETRIP_INCLUDES_DIR . 'cmb2/init.php' ) ) {
	require_once FILETRIP_INCLUDES_DIR . 'cmb2/init.php';
}

/**
 * Conditionally displays a field when used as a callback in the 'show_on_cb' field parameter
 *
 * @param  FILETRIP_CMB2_Field object $field Field object
 *
 * @return bool                     True if metabox should show
 */
function filetrip_cmb_hide_if_no_cats( $field ) {
	// Don't show this field if not in the cats category
	if ( ! has_tag( 'cats', $field->object_id ) ) {
		return false;
	}
	return true;
}

add_filter( 'cmb2_admin_init', 'filetrip_channel_metaboxes' );
/**
 * Define the metabox and field configurations.
 *
 * @param  array $meta_boxes
 * @return array
 */

function filetrip_get_icon( $img_name, $name = '', $size = '30', $link = '', $title = '' ) {
	// If there is no link? Don't add href
	$href_start = '<a target="_blank" href="' . $link . '">';
	$href_end   = '</a> ';
	if ( empty( $link ) ) {
		$href_start = '';
		$href_end   = '';
	}

	return $href_start . '<img title="' . $title . '" src="' . FILETRIP_PLUGIN_URL . '/assets/img/' . $img_name . '.png" width="' . $size . '" height="' . $size . '">' . $href_end . $name;
}

function filetrip_channel_metaboxes() {
	 $prefix          = Filetrip_Constants::METABOX_PREFIX;
	$dropbox_settings = 'filetrip_dropbox_setting';
	$drive_settings   = 'filetrip_google_drive_setting';

	$link_upload_options = array();

	# Check for which channels are active and add linking cdn option for each one of them
	$link_upload_options = apply_filters( 'filetrip_channel_cdn_selection', $link_upload_options );

	// Start with an underscore to hide fields from custom fields list
	$metbox_config_channel = array(
		'id'           => 'filetrip_forward_selection',
		'title'        => esc_attr__( 'Filetrip channel selection', 'filetrip-plugin' ),
		'object_types' => array( Filetrip_Constants::POST_TYPE ), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true,
		'fields'       => array(
			'channels' =>
				array(
					'name'    => 'Upload channel',
					'desc'    => 'Select a channel where you want your files to be uploaded after they get approved ?',
					'id'      => $prefix . 'channel_select',
					'type'    => 'multicheck',
					'options' => array(
						'wordpress' => filetrip_get_icon( 'wordpress', ' Wordpress' ),
					),
				),
		),
	);

	$metbox_config_channel = apply_filters( 'filetrip_channel_selection_filter', $metbox_config_channel );

	$filetrip_channel_selection = new_cmb2_box(
		$metbox_config_channel
	);

	$filetrip_cdn_config = array(
		'id'           => 'filetrip_fcdn_selection',
		'title'        => esc_attr__( 'Generate shared links', 'filetrip-plugin' ),
		'object_types' => array( Filetrip_Constants::POST_TYPE ), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true,
		'fields'       =>
		array(
			'channels' =>
				array(
					'name'    => 'Generate shared Link',
					'desc'    => 'Whatever channel you select will be used as base links with form & email attachment submissions',
					'id'      => $prefix . 'cdn_select',
					'type'    => 'radio',
					'options' => $link_upload_options,
				),
		),
	);

	$filetrip_cdn_selection = new_cmb2_box( $filetrip_cdn_config );

	$filetrip_metabox = new_cmb2_box(
		array(
			'id'           => 'filetrip_fmetabox',
			'title'        => 'FileTrip multi-file uploader options',
			'filetrip-plugin',
			'object_types' => array( Filetrip_Constants::POST_TYPE ), // Post type
			'context'      => 'normal',
			'priority'     => 'high',
			'show_names'   => true,
			'fields'       => array(
				array(
					'name' => esc_attr__( 'Allow guests', 'filetrip-plugin' ),
					'desc' => esc_attr__( 'Allow guests to upload files', 'filetrip-plugin' ),
					'id'   => $prefix . 'allow_guests',
					'type' => 'checkbox',
				),
				array(
					'name' => esc_attr__( 'Enforce information submission', 'filetrip-plugin' ),
					'desc' => esc_attr__( 'Enforce users to submit Title and Description for each upload.', 'filetrip-plugin' ),
					'id'   => $prefix . 'enforce_info',
					'type' => 'checkbox',
				),
				array(
					'name' => esc_attr__( 'Information submission is required', 'filetrip-plugin' ),
					'desc' => esc_attr__( 'Users must submit information for the upload to execute.', 'filetrip-plugin' ),
					'id'   => $prefix . 'required',
					'type' => 'checkbox',
				),
				array(
					'name' => esc_attr__( 'Disable Drag & Drop effect', 'filetrip-plugin' ),
					'desc' => esc_attr__( 'Use native browse button for file upload.', 'filetrip-plugin' ),
					'id'   => $prefix . 'disable_drag_drop',
					'type' => 'checkbox',
				),
				array(
					'name' => esc_attr__( 'Disable file preview', 'filetrip-plugin' ),
					'desc' => esc_attr__( 'Disable file preview feature', 'filetrip-plugin' ),
					'id'   => $prefix . 'file_preview',
					'type' => 'checkbox',
				),
				array(
					'name' => esc_attr__( 'Uploader mode (Disable Multipart)', 'filetrip-plugin' ),
					'desc' => __( 'Enable this option if you do not want to use the native Wordpress uploader. <br/><span style="color:red">Multipart is recommended for uploading larger files (>32MB)</span>', 'filetrip-plugin' ),
					'id'   => $prefix . 'multipart_uploader',
					'type' => 'checkbox',
				),
				array(
					'name'            => esc_attr__( 'Max file size (MB)', 'filetrip-plugin' ),
					'desc'            => esc_attr__( '(MB) Max upload file size allowed.', 'filetrip-plugin' ),
					'id'              => $prefix . 'max_file_size',
					'type'            => 'text_small',
					'default'         => '10',
					'sanitization_cb' => 'filetrip_number_sanitization', // custom sanitization callback parameter
							  // 'escape_cb'       => 'number_escaping',  // custom escaping callback parameter
					'attributes'      => array(
						'placeholder' => 10,
					),
				),
				array(
					'name'            => esc_attr__( 'Max files limit)', 'filetrip-plugin' ),
					'desc'            => esc_attr__( 'Max upload files limit.', 'filetrip-plugin' ),
					'id'              => $prefix . 'file_upload_limit',
					'type'            => 'text_small',
					'default'         => '10',
					'sanitization_cb' => 'filetrip_number_sanitization', // custom sanitization callback parameter
					'attributes'      => array(
						'placeholder' => 10,
					),
				),
				array(
					'name'       => esc_attr__( 'Strictly allow extensions', 'filetrip-plugin' ),
					'desc'       => 'Allow only these extensions (Use comma seperator). Leave it empty to allow WP default mime list. <br><a href="' . admin_url( Filetrip_Constants::OPTION_PAGE ) . '">' . esc_attr__('To customize mime', 'filetrip-plugin') . '</a>',
					'id'         => $prefix . 'strict_extensions',
					'type'       => 'text',
					'attributes' => array(
						'placeholder' => 'avi, wmv, png, jpg',
					),
				),
				array(
					'name' => esc_attr__( 'Debug', 'filetrip-plugin' ),
					'desc' => esc_attr__( 'Print out debug messages', 'filetrip-plugin' ),
					'id'   => $prefix . 'debug',
					'type' => 'checkbox',
				),
				array(
					'name'       => esc_attr__( 'Debugging info target', 'filetrip-plugin' ),
					'desc'       => esc_attr__( 'For class name add "." letter prefix. For ID targeting put "#" letter', 'filetrip-plugin' ),
					'id'         => $prefix . 'target_debug',
					'type'       => 'text',
					'attributes' => array(
						'placeholder' => '#output-name',
					),
				),
				array(
					'name'       => esc_attr__( 'Uploader message', 'filetrip-plugin' ),
					'desc'       => esc_attr__( 'Label that will be displayed in the bottom of the uploader box', 'filetrip-plugin' ),
					'id'         => $prefix . 'label',
					'type'       => 'text',
					'attributes' => array(
						'placeholder' => 'Allowed file types are psd, ai, bmp, svg, tiff, gif, jpg, and png.',
					),
				),
				// Drop box section
				array(
					'name'       => esc_attr__( 'Drop file box label', 'filetrip-plugin' ),
					'desc'       => esc_attr__( 'Change drop file box label from here', 'filetrip-plugin' ),
					'id'         => $prefix . 'drop_box_title',
					'type'       => 'text',
					'attributes' => array(
						'placeholder' => 'Drop your files here',
					),
				),
				array(
					'name'            => esc_attr__( 'Drop box label font size', 'filetrip-plugin' ),
					'desc'            => esc_attr__( 'Change the font size of the drop file box label from here.', 'filetrip-plugin' ),
					'id'              => $prefix . 'drop_box_font_size',
					'type'            => 'text_small',
					'default'         => '26',
					'sanitization_cb' => 'filetripgold_number_sanitization', // custom sanitization callback parameter
							  // 'escape_cb'       => 'number_escaping',  // custom escaping callback parameter
					'attributes'      => array(
						'placeholder' => 26,
					),
				),
				array(
					'name'            => esc_attr__( 'Change the height of the uploader box', 'filetrip-plugin' ),
					'desc'            => esc_attr__( 'Modify the height of the uploader box.', 'filetrip-plugin' ),
					'id'              => $prefix . 'drop_box_height',
					'type'            => 'text_small',
					'default'         => '100',
					'sanitization_cb' => 'filetripgold_number_sanitization', // custom sanitization callback parameter
							  // 'escape_cb'       => 'number_escaping',  // custom escaping callback parameter
					'attributes'      => array(
						'placeholder' => 100,
					),
				),
				array(
					'name'       => esc_attr__( 'File Title placeholder', 'filetrip-plugin' ),
					'desc'       => esc_attr__( 'Customize title placeholder', 'filetrip-plugin' ),
					'id'         => $prefix . 'title_placeholder',
					'type'       => 'text',
					'attributes' => array(
						'placeholder' => 'Enter file title...',
					),
				),
				array(
					'name'       => esc_attr__( 'File Description placeholder', 'filetrip-plugin' ),
					'desc'       => esc_attr__( 'Customize description placeholder', 'filetrip-plugin' ),
					'id'         => $prefix . 'desc_placeholder',
					'type'       => 'text',
					'attributes' => array(
						'placeholder' => 'Enter file description...',
					),
				),
				array(
					'name' => esc_attr__( 'Theme options', 'filetrip-plugin' ),
					'desc' => esc_attr__( 'Options related to plugin theme.', 'filetrip-plugin' ),
					'id'   => $prefix . 'test_title',
					'type' => 'title',
				),
				array(
					'name'    => esc_attr__( 'Change uploader\'s theme', 'filetrip-plugin' ),
					'desc'    => esc_attr__( 'Select the suitable theme for your website.', 'filetrip-plugin' ),
					'id'      => $prefix . 'uploader_theme',
					'type'    => 'select',
					'default' => array( 'simplex' ),
					'options' => array(
						'simplex'       => esc_attr__( 'Simplex', 'filetrip-plugin' ),
						'default'       => esc_attr__( 'Big style', 'filetrip-plugin' ),
						'super-simplex' => esc_attr__( 'Super Simplex', 'filetrip-plugin' ),
					),
					// 'inline'  => true, // Toggles display to inline
				),

				array(
					'name'  => esc_attr__( 'Icon image', 'filetrip-plugin' ),
					'desc'  => __( 'Uploader icon image with dimension less than <b>(110x110)px</b> ', 'filetrip-plugin' ),
					'id'    => $prefix . 'icon_image',
					'type'  => 'file',
					'allow' => array( 'url', 'attachment' ), // limit to just attachments with array( 'attachment' )
				),
				array(
					'name'    => esc_attr__( 'Upload item color', 'filetrip-plugin' ),
					'desc'    => esc_attr__( 'Change the background color of an upload entries', 'filetrip-plugin' ),
					'id'      => $prefix . 'background_color',
					'type'    => 'colorpicker',
					'default' => '',
				),
				array(
					'name'    => esc_attr__( 'Logo Color', 'filetrip-plugin' ),
					'desc'    => esc_attr__( 'Logo color', 'filetrip-plugin' ),
					'id'      => $prefix . 'logo_color',
					'type'    => 'colorpicker',
					'default' => '#639AFF',
				),
				array(
					'name'    => esc_attr__( 'Text color', 'filetrip-plugin' ),
					'desc'    => esc_attr__( 'Text color', 'filetrip-plugin' ),
					'id'      => $prefix . 'text_color',
					'type'    => 'colorpicker',
					'default' => '#818080',
				),
				array(
					'name'    => esc_attr__( 'Upload border color', 'filetrip-plugin' ),
					'desc'    => esc_attr__( 'Upload border color', 'filetrip-plugin' ),
					'id'      => $prefix . 'border_color',
					'type'    => 'colorpicker',
					'default' => '#cecece',
				),
				array(
					'name'    => esc_attr__( 'Label Color', 'filetrip-plugin' ),
					'desc'    => esc_attr__( 'Upload label text color', 'filetrip-plugin' ),
					'id'      => $prefix . 'label_color',
					'type'    => 'colorpicker',
					'default' => '#818080',
				),
			),
		)
	);
}
