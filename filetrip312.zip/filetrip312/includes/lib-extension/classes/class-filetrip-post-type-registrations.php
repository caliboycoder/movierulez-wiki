<?php
/**
 * Portfolio Post Type
 *
 * @package   Filetrip_Post_Type
 * @author    Abdulrhman Elbuni
 * @license   GPL-2.0+
 * @copyright 2013-2014
 */

/**
 * Register filetrip types and taxonomies.
 *
 * @package Filetrip_Post_Type
 */
class Filetrip_Post_Type_Registrations {

	public $post_type   = 'filetrip';
	public $c_post_type = 'Filetrip';

	public $taxonomies = array( 'filetrip_category', 'filetrip_tag' );

	public function init() {
		// Add the portfolio post type and taxonomies
		add_action( 'init', array( $this, 'register' ) );
	}

	/**
	 * Initiate registrations of post type and taxonomies.
	 *
	 * @uses Portfolio_Post_Type_Registrations::register_post_type()
	 * @uses Portfolio_Post_Type_Registrations::register_taxonomy_tag()
	 * @uses Portfolio_Post_Type_Registrations::register_taxonomy_category()
	 */
	public function register() {
		$this->register_post_type();
		flush_rewrite_rules();
		// $this->register_taxonomy_category();
		// $this->register_taxonomy_tag();
	}

	/**
	 * Register the custom post type.
	 *
	 * @link http://codex.wordpress.org/Function_Reference/register_post_type
	 */
	protected function register_post_type() {
		$labels = array(
			'name'               => esc_attr__( 'Filetrip', 'filetrip-plugin' ),
			'singular_name'      => esc_attr__( 'Filetrip Item', 'filetrip-plugin' ),
			'add_new'            => esc_attr__( 'Add New Uploader', 'filetrip-plugin' ),
			'add_new_item'       => esc_attr__( 'Add New Filetrip Item', 'filetrip-plugin' ),
			'edit_item'          => esc_attr__( 'Edit Filetrip Item', 'filetrip-plugin' ),
			'new_item'           => esc_attr__( 'Add New Filetrip Item', 'filetrip-plugin' ),
			'view_item'          => esc_attr__( 'View Item', 'filetrip-plugin' ),
			'search_items'       => esc_attr__( 'Search Filetrip', 'filetrip-plugin' ),
			'not_found'          => esc_attr__( 'No Filetrip items found', 'filetrip-plugin' ),
			'not_found_in_trash' => esc_attr__( 'No Filetrip items found in trash', 'filetrip-plugin' ),
		);

		$supports = array(
			'title',
			// 'editor',
			// 'excerpt',
			// 'thumbnail',
			// 'comments',
				'author',
		// 'custom-fields',
		// 'revisions',
		);

		$args = array(
			'labels'          => $labels,
			'supports'        => $supports,
			'public'          => true,
			'capability_type' => 'post',
			'rewrite'         => array( 'slug' => 'filetrip' ), // Permalinks format
			'menu_position'   => 5,
			'menu_icon'       => ( version_compare( $GLOBALS['wp_version'], '3.8', '>=' ) ) ? 'dashicons-cloud' : '',
			'has_archive'     => true,
		);

		$args = apply_filters( 'filetrip_posttype_args', $args );

		register_post_type( $this->post_type, $args );
	}

	/**
	 * Register a taxonomy for  Filetrip  Categories.
	 *
	 * @link http://codex.wordpress.org/Function_Reference/register_taxonomy
	 */
	protected function register_taxonomy_category() {
		$labels = array(
			'name'                       => esc_attr__( 'Filetrip Categories', 'filetrip-plugin' ),
			'singular_name'              => esc_attr__( 'Filetrip Category', 'filetrip-plugin' ),
			'menu_name'                  => esc_attr__( 'Filetrip Categories', 'filetrip-plugin' ),
			'edit_item'                  => esc_attr__( 'Edit Filetrip Category', 'filetrip-plugin' ),
			'update_item'                => esc_attr__( 'Update Filetrip Category', 'filetrip-plugin' ),
			'add_new_item'               => esc_attr__( 'Add New Filetrip Category', 'filetrip-plugin' ),
			'new_item_name'              => esc_attr__( 'New Filetrip Category Name', 'filetrip-plugin' ),
			'parent_item'                => esc_attr__( 'Parent Filetrip Category', 'filetrip-plugin' ),
			'parent_item_colon'          => esc_attr__( 'Parent Filetrip Category:', 'filetrip-plugin' ),
			'all_items'                  => esc_attr__( 'All Filetrip Categories', 'filetrip-plugin' ),
			'search_items'               => esc_attr__( 'Search Filetrip Categories', 'filetrip-plugin' ),
			'popular_items'              => esc_attr__( 'Popular Filetrip Categories', 'filetrip-plugin' ),
			'separate_items_with_commas' => esc_attr__( 'Separate Filetrip categories with commas', 'filetrip-plugin' ),
			'add_or_remove_items'        => esc_attr__( 'Add or remove Filetrip categories', 'filetrip-plugin' ),
			'choose_from_most_used'      => esc_attr__( 'Choose from the most used Filetrip categories', 'filetrip-plugin' ),
			'not_found'                  => esc_attr__( 'No Filetrip categories found.', 'filetrip-plugin' ),
		);

		$args = array(
			'labels'            => $labels,
			'public'            => true,
			'show_in_nav_menus' => true,
			'show_ui'           => true,
			'show_tagcloud'     => true,
			'hierarchical'      => true,
			'rewrite'           => array( 'slug' => 'filetrip_category' ),
			'show_admin_column' => true,
			'query_var'         => true,
		);

		$args = apply_filters( 'filetrip_posttype_category_args', $args );

		register_taxonomy( $this->taxonomies[0], $this->post_type, $args );
	}

	/**
	 * Register a taxonomy for Filetrip Tags.
	 *
	 * @link http://codex.wordpress.org/Function_Reference/register_taxonomy
	 */
	protected function register_taxonomy_tag() {
		$labels = array(
			'name'                       => esc_attr__( 'Filetrip Tags', 'filetrip-plugin' ),
			'singular_name'              => esc_attr__( 'Filetrip Tag', 'filetrip-plugin' ),
			'menu_name'                  => esc_attr__( 'Filetrip Tags', 'filetrip-plugin' ),
			'edit_item'                  => esc_attr__( 'Edit Filetrip Tag', 'filetrip-plugin' ),
			'update_item'                => esc_attr__( 'Update Filetrip Tag', 'filetrip-plugin' ),
			'add_new_item'               => esc_attr__( 'Add New Filetrip Tag', 'filetrip-plugin' ),
			'new_item_name'              => esc_attr__( 'New Filetrip Tag Name', 'filetrip-plugin' ),
			'parent_item'                => esc_attr__( 'Parent Filetrip Tag', 'filetrip-plugin' ),
			'parent_item_colon'          => esc_attr__( 'Parent Filetrip Tag:', 'filetrip-plugin' ),
			'all_items'                  => esc_attr__( 'All Filetrip Tags', 'filetrip-plugin' ),
			'search_items'               => esc_attr__( 'Search Filetrip Tags', 'filetrip-plugin' ),
			'popular_items'              => esc_attr__( 'Popular Filetrip Tags', 'filetrip-plugin' ),
			'separate_items_with_commas' => esc_attr__( 'Separate filetrip tags with commas', 'filetrip-plugin' ),
			'add_or_remove_items'        => esc_attr__( 'Add or remove filetrip tags', 'filetrip-plugin' ),
			'choose_from_most_used'      => esc_attr__( 'Choose from the most used filetrip tags', 'filetrip-plugin' ),
			'not_found'                  => esc_attr__( 'No filetrip tags found.', 'filetrip-plugin' ),
		);

		$args = array(
			'labels'            => $labels,
			'public'            => true,
			'show_in_nav_menus' => true,
			'show_ui'           => true,
			'show_tagcloud'     => true,
			'hierarchical'      => false,
			'rewrite'           => array( 'slug' => 'filetrip_tag' ),
			'show_admin_column' => true,
			'query_var'         => true,
		);

		$args = apply_filters( 'filetrip_posttype_tag_args', $args );

		register_taxonomy( $this->taxonomies[1], $this->post_type, $args );
	}
}
