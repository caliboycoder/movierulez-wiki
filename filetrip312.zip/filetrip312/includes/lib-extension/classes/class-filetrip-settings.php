<?php
/**
 * Frontend Uploader Settings
 */
class Filetrip_Settings {

	private $settings_api;

	public function __construct() {
		$this->settings_api = new Filetrip_Settings_API();

		add_action( 'current_screen', array( $this, 'action_current_screen' ) );
		add_action( 'admin_menu', array( $this, 'action_admin_menu' ) );
	}

	/**
	 * Only run if current screen is plugin settings or options.php
	 *
	 * @return [type] [description]
	 */
	public function action_current_screen() {
		$this->settings_api->set_sections( $this->get_settings_sections() );
		$this->settings_api->set_fields( $this->get_settings_fields() );

		// Initialize settings
		$this->settings_api->admin_init( $this );
	}

	public function header_top_calback() {
		// Channels will use this action to update their current active status in setting page
		do_action( 'filetrip_settings_page_header' );
	}

	public static function check_if_backup_disabled() {
		// If backup is disabled
		$temp_settings = get_option( Filetrip_Uploader::$settings_slug, false );
		if ( $temp_settings != false && isset( $temp_settings['disable_backup'] ) && 'on' == $temp_settings['disable_backup'] ) {
			// Cancel and do nothing
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Get post types for checkbox option
	 *
	 * @return array of slug => label for registered post types
	 */
	public static function get_post_types() {
		$filetrip_public_post_types = get_post_types( array( 'public' => true ), 'objects' );
		foreach ( $filetrip_public_post_types as $slug => $post_object ) {
			if ( $slug == 'attachment' ) {
				unset( $filetrip_public_post_types[ $slug ] );
				continue;
			}
			$filetrip_public_post_types[ $slug ] = $post_object->labels->name;
		}
		return $filetrip_public_post_types;
	}

	public function action_admin_menu() {
		add_submenu_page( 'edit.php?post_type=' . Filetrip_Constants::POST_TYPE, 'Settings', 'Settings', 'edit_posts', Filetrip_Constants::POST_TYPE . '_settings', array( $this, 'plugin_page' ) );
	}

	public function get_settings_sections() {
		$sections = array(
			array(
				'id'    => Filetrip_Constants::POST_TYPE . '_settings',
				'title' => esc_attr__( 'FileTrip Settings', 'filetrip-plugin' ),
			),
			array(
				'id'    => Filetrip_Constants::POST_TYPE . '_mime_setting',
				'title' => esc_attr__( 'MIME Settings', 'filetrip-plugin' ),
			),
		);

		// Allow destination widgets to add their own config section
		$sections = apply_filters( 'filetrip_settings_add_section', $sections );

		return $sections;
	}

	/**
	 * Returns all the settings fields
	 *
	 * @return array settings fields
	 */
	public static function get_settings_fields() {
		;

		$settings_fields = array(
			Filetrip_Constants::POST_TYPE . '_settings' => array(
				array(
					'name'    => 'enable_auto_delete',
					'label'   => esc_attr__( 'Automatically delete files from Wordpress', 'filetrip-plugin' ),
					'desc'    => esc_attr__( 'Automatically delete files from Wordpress if they have been successfully sent to all other selected channels.', 'filetrip-plugin' ),
					'type'    => 'checkbox',
					'default' => '',
				),
				array(
					'name'    => 'notify_admin_uploads',
					'label'   => esc_attr__( 'Notify site admin', 'filetrip-plugin' ),
					'desc'    => esc_attr__( 'Notify admin about new uploads', 'filetrip-plugin' ),
					'type'    => 'checkbox',
					'default' => '',
				),
				array(
					'name'    => 'notify_admin_backup',
					'label'   => '',
					'desc'    => esc_attr__( 'Notify admin about new backups', 'filetrip-plugin' ),
					'type'    => 'checkbox',
					'default' => '',
				),
				array(
					'name'    => 'auto_approve_user_files',
					'label'   => esc_attr__( 'Auto-approve user uploads', 'filetrip-plugin' ),
					'desc'    => __( '<b style="color:red">Not Recommended</b>: <span style="font-size:12px">Be-careful, by enabling this feature you might make your Users wait for a long time. As it will take a prolong time to iterate through uploaded files; and, start forwarding the files into all of your selected channels.</span> <br><b><span style="font-size:10px">(EXAMPLE: So for a 100MB file with all channels selected, your server must transfer the same file 4 times to 4 different channels; which might force it to timeout and generate <b>Error 404</b>)</span>', 'filetrip-plugin' ),
					'type'    => 'checkbox',
					'default' => '',
				),
				array(
					'name'              => 'admin_notification_text',
					'label'             => esc_attr__( 'Admin Notification', 'filetrip-plugin' ),
					'desc'              => esc_attr__( 'Message that admin will get on new file upload', 'filetrip-plugin' ),
					'type'              => 'wysiwyg',
					'default'           => 'Someone uploaded a new ' . ucfirst( Filetrip_Constants::PLUGIN_NAME ) . ' file, please moderate at:<br>' .
							'<a href="' . admin_url( Filetrip_Constants::UPLOAD_PAGE_MENU ) . '">Review &amp; Approve</a>',
					'sanitize_callback' => 'wp_filter_post_kses',
				),
				array(
					'name'              => 'notification_email',
					'label'             => esc_attr__( 'Notification email', 'filetrip-plugin' ),
					'desc'              => esc_attr__( 'Leave blank to use site admin email', 'filetrip-plugin' ),
					'type'              => 'text',
					'default'           => '',
					'sanitize_callback' => 'sanitize_email',
				),
			),
			Filetrip_Constants::POST_TYPE . '_mime_setting' => array(
				array(
					'name'    => 'enabled_files',
					'label'   => esc_attr__( 'Allow extra file types to be uploaded in addition to the extensions allowed natively by Wordpress', 'filetrip-plugin' ),
					'desc'    => '',
					'type'    => 'multicheck',
					'default' => array(),
					'options' => FILETRIP_get_exts_descs(),
				),
			),
			Filetrip_Constants::POST_TYPE . '_backup_setting' => array(
				array(
					'name'    => 'schedule_type',
					'label'   => esc_attr__( 'Backup', 'filetrip-plugin' ),
					'desc'    => '',
					'type'    => 'select',
					'default' => 'complete',
					'options' => array(
						'complete' => 'Both Database & Files',
						'file'     => 'Files only',
						'database' => 'Database Only',
					),
				),
				array(
					'name'    => 'schedule_recurrence_type',
					'label'   => esc_attr__( 'Schedule', 'filetrip-plugin' ),
					'desc'    => '',
					'type'    => 'select',
					'default' => 'manually',
					'options' => array(
						'manually'                 => 'Manual Only',
						'filetrip_bkp_hourly'      => 'Once Hourly',
						'filetrip_bkp_twicedaily'  => 'Twice Daily',
						'filetrip_bkp_daily'       => 'Once Daily',
						'filetrip_bkp_weekly'      => 'Once Weekly',
						'filetrip_bkp_fortnightly' => 'Once Biweekly',
						'filetrip_bkp_monthly'     => 'Once Monthly',
					),
				),
				array(
					'name'    => 'schedule_start_week_day',
					'label'   => esc_attr__( 'Start day', 'filetrip-plugin' ),
					'desc'    => '',
					'type'    => 'select',
					'default' => 'manually',
					'class'   => 'recurring-setting start-day',
					'options' => array(
						'monday'    => 'Monday',
						'tuesday'   => 'Tuesday',
						'wednesday' => 'Wednesday',
						'thursday'  => 'Thursday',
						'friday'    => 'Friday',
						'saturday'  => 'Saturday',
						'sunday'    => 'Sunday',
					),
				),
				array(
					'name'    => 'schedule_start_month_day',
					'label'   => esc_attr__( 'Start day of month', 'filetrip-plugin' ),
					'desc'    => '',
					'type'    => 'number_day',
					'default' => '1',
				),
				array(
					'name'  => 'schedule_start_time',
					'label' => esc_attr__( 'Start time', 'filetrip-plugin' ),
					'desc'  => '',
					'type'  => 'hours_minutes',
				),
				array(
					'name'    => 'no_max_backups',
					'label'   => esc_attr__( 'Number of backups to store on this server', 'filetrip-plugin' ),
					'desc'    => esc_attr__( 'Past this limit, older backups will be deleted automatically.', 'filetrip-plugin' ),
					'type'    => 'number_backup',
					'default' => '2',
				),
				array(
					'name'    => 'backup_now',
					'label'   => esc_attr__( 'Immediate backup', 'filetrip-plugin' ),
					'desc'    => esc_attr__( 'Backup with the same above settings.', 'filetrip-plugin' ),
					'type'    => 'backup_now',
					'default' => '2',
				),
			),
		);

		// Allow destination channels to extend setting fields and their own setting
		$settings_fields = apply_filters( 'filetrip_settings_add_section_fields', $settings_fields );

		return $settings_fields;
	}

	/**
	 * Render the UI
	 */
	public function plugin_page() {
		echo filetrip_get_icon( 'logo-text', '', '', Filetrip_Constants::ITF_WEBSITE_LINK );
		echo '<div class="wrap">';
		$this->header_top_calback();
		$this->settings_api->show_navigation();
		$this->settings_api->show_forms();
		echo '</div>';
	}
}

// Instantiate
$filetrip_settings = new Filetrip_Settings();
