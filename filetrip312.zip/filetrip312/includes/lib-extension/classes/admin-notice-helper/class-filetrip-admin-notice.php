<div class="anh_message <?php echo $class; ?>">
	<?php foreach ( $this->notices[ $type ] as $filetrip_notice ) : ?>
		<p><?php echo wp_kses( $filetrip_notice, wp_kses_allowed_html( 'post' ) ); ?></p>
	<?php endforeach; ?>
</div>
