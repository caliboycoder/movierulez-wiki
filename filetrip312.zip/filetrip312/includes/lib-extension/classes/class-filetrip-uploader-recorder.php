<?php

/*
 * This calss should provide an abstraction for database record handling
 */


class Filetrip_Uploader_Recorder {

	private $api_selection;

	public function __construct( $selection ) {
		$this->api_selection = $selection;
	}

	// Return uploaded files for a specific user
	public static function get_files_for_user( $filetrip_uploader_ids, $user_ids = -1 ) {
		// Filetrip return image object structure
		// stdClass Object
		/*(
		[id] => 1
		[user_id] => 1
		[att_id] => 2134
		[arfaly_uploader_id] => 1932
		[att_size] => 396195
		[time] => 2015-10-04 17:51:56
		[dropbox_sent] =>
		[drive_sent] =>
		[ftp_sent] =>
		[dropbox_cdn] =>
		[drive_cdn] =>
		[short_url] =>
		)*/
		global $wpdb;
		$where_userid               = '(';
		$where_filetrip_uploader_id = '(';

		/*======================================================*/
		/*=================Generate Where======================*/
		// Filter user_ids
		for ( $i = 0; $i < count( $user_ids );$i++ ) {
			// Guest users have ID of 0, so make sure to replace it with -100 for successful storage
			if ( $user_ids[ $i ] == 0 ) {
				$user_ids[ $i ] = -100;
			}

			if ( $i < ( count( $user_ids ) - 1 ) ) {
				$where_userid = $where_userid . 'user_id=' . $user_ids[ $i ] . ' OR ';
			} else {
				$where_userid = $where_userid . 'user_id=' . $user_ids[ $i ] . ')';
			}
		}

		if ( $filetrip_uploader_ids != '' ) {
			for ( $i = 0; $i < count( $filetrip_uploader_ids );$i++ ) {
				if ( $i < ( count( $filetrip_uploader_ids ) - 1 ) ) {
					$where_filetrip_uploader_id = $where_filetrip_uploader_id . 'filetrip_uploader_id=' . $filetrip_uploader_ids[ $i ] . ' OR ';
				} else {
					$where_filetrip_uploader_id = $where_filetrip_uploader_id . 'filetrip_uploader_id=' . $filetrip_uploader_ids[ $i ] . ')';
				}
			}
		}

		/*=================Generate Where END===================*/
		/*======================================================*/

		// If there was no filetrip ID, return the whole images for a single user
		if ( $filetrip_uploader_ids == '' ) {
			$existing_img = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %s WHERE %s;', Filetrip_Constants::DB_PREFIX . Filetrip_Constants::RECORD_TABLE_NAME, $where_userid ), ARRAY_A );
			return $existing_img;
		} else {
			$existing_img = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %s WHERE %s AND %s;', Filetrip_Constants::DB_PREFIX . Filetrip_Constants::RECORD_TABLE_NAME, $where_filetrip_uploader_id, $where_userid ), ARRAY_A );
			// print_r($select_query);
			return $existing_img;
		}

		return false;
	}

	// This function will be called when new file is been uploaded successfully
	public static function register_uploaded_file( $att_id, $filetrip_uploader_id, $user_id, $att_size ) {
		global $wpdb;

		try {
			$wpdb->replace(
				Filetrip_Constants::DB_PREFIX . Filetrip_Constants::RECORD_TABLE_NAME,
				array(
					'user_id'            => $user_id,
					'att_id'             => $att_id,
					'arfaly_uploader_id' => $filetrip_uploader_id,
					'att_size'           => $att_size,
					'time'               => gmdate( 'Y-m-d H:i:s' ),
				),
				array(
					'%d',
					'%d',
					'%d',
					'%s',
					'%s',
				)
			);
		} catch ( Exception $ex ) {
			Report_Error( 'Database insert error, check your error log file' );
		}
	}

	public static function database_cleansing() {
		global $wpdb;

		$upload_records = Filetrip_Uploader_Recorder::get_uploaded_files();

		foreach ( $upload_records as $upload ) {
			$upload_obj = wp_get_attachment_image_src( $upload['att_id'] );
			// If the attachment is not available, remove it
			if ( ! $upload_obj ) {
				// Delete record if the attachment is no longer exist
				$wpdb->update(
					Filetrip_Constants::DB_PREFIX . Filetrip_Constants::RECORD_TABLE_NAME,
					array(
						'is_deleted' => 1,
					),
					array(
						'att_id' => intval( $upload['att_id'] ),
					),
					array( '%d' ),
					array( '%d' )
				);
			}
		}
	}

	public static function get_uploaded_files() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$existing_uploads = $wpdb->get_results( 'SELECT * FROM ' . Filetrip_Constants::DB_PREFIX . Filetrip_Constants::RECORD_TABLE_NAME, ARRAY_A );

		return $existing_uploads;
	}
}
