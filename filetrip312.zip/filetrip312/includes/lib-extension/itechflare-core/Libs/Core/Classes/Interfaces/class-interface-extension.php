<?php
/**
 * Interface of Module
 */
namespace FileTrip\WP\Extensions\Core\Interfaces;

interface Interface_Extension {

	public static function extensionGetInstance();
	public function extensionGetName();
	public function extensionGetUri();
	public function extensionGetAuthor();
	public function extensionGetAuthorUri();
	public function extensionGetVersion();
}
