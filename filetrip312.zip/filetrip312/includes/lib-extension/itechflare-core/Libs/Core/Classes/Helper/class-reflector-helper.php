<?php

namespace FileTrip\WP\Extensions\Core\Helper;

use FileTrip\WP\Extensions\Core\Abstracts\ITF_Reflector;

/**
 * Class Reflector_Helper
 *
 * @package FileTrip\WP\Extensions\Core\Helper
 * @final
 */
final class Reflector_Helper extends ITF_Reflector {

}
