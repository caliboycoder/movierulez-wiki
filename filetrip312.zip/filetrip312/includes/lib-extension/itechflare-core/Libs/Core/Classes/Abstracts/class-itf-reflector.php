<?php

namespace FileTrip\WP\Extensions\Core\Abstracts;

/**
 * Class ITF_Reflector
 *
 * @package FileTrip\WP\Extensions\Core\Abstracts
 * @abstract
 */
abstract class ITF_Reflector {


	/**
	 * @var string
	 */
	private $abstract_object_name;

	/**
	 * @var string
	 */
	private $abstract_short_name;

	/**
	 * @var string
	 */
	private $abstract_name_space;

	/**
	 * @var \ReflectionClass
	 */
	private $abstract_reflection;

	/**
	 * @var string
	 */
	private $abstract_path;

	/**
	 * ReflectorAbstract constructor.
	 *
	 * @param object|string $class
	 */
	final public function __construct( $class ) {
		if ( is_object( $class ) || is_string( $class ) && class_exists( $class ) ) {
			$this->abstract_object_name = is_object( $class ) ? get_class( $class ) : $class;
		}

		if ( $this->isValid() ) {
			$this->abstract_reflection = new \ReflectionClass( $class );
			// override with real value
			$this->abstract_object_name = $this->abstract_reflection->getName();
			$this->abstract_short_name  = $this->abstract_reflection->getShortName();
			$this->abstract_name_space  = ! $this->abstract_reflection->inNamespace()
				? null : $this->abstract_reflection->getNamespaceName();
			$this->abstract_path        = $this->abstract_reflection->getFileName();
		}
	}

	/**
	 * Check if Class Valid
	 *
	 * @return bool
	 */
	final public function isValid() {
		return is_string( $this->abstract_object_name );
	}

	/**
	 * @return \ReflectionClass|bool
	 */
	final public function getAbstractReflection() {
		if ( $this->isValid() ) {
			return new \ReflectionClass( $this->abstract_object_name );
		}

		return false;
	}

	/**
	 * @return string
	 */
	final public function getName() {
		return $this->abstract_object_name;
	}

	/**
	 * @return string
	 */
	final public function getAbstractShortName() {
		return $this->abstract_short_name;
	}

	/**
	 * @return string
	 */
	final public function getShortName() {
		return $this->abstract_short_name;
	}

	/**
	 * @return string
	 */
	final public function getAbstractObjectName() {
		return $this->abstract_object_name;
	}

	/**
	 * @return bool
	 */
	final public function hasNameSpace() {
		return $this->abstract_name_space !== false;
	}

	/**
	 * @return bool
	 */
	final public function inNameSpace() {
		return $this->hasNameSpace();
	}

	/**
	 * @return bool|string
	 */
	final public function getAbstractNameSpace() {
		return $this->abstract_name_space;
	}

	/**
	 * @return bool|string
	 */
	final public function getNameSpace() {
		return $this->abstract_name_space;
	}

	/**
	 * @return null|string
	 */
	final public function getFileName() {
		return $this->abstract_path;
	}

	/**
	 * @return bool|string
	 */
	final public function getAbstractPath() {
		return $this->abstract_path;
	}

	/**
	 * @return bool|string
	 */
	final public function getPath() {
		return $this->abstract_path;
	}

	/**
	 * @return bool|string
	 */
	final public function getDirName() {
		return $this->abstract_path ? dirname( $this->abstract_path ) : false;
	}

	/**
	 * @return bool|string
	 */
	final public function getDirectory() {
		return $this->getDirName();
	}

	/**
	 * @param string $name
	 *
	 * @return bool
	 */
	final public function hasMethod( $name ) {
		return is_string( $name ) && $this->abstract_reflection && $this->abstract_reflection->hasMethod( $name );
	}

	/**
	 * @param string $name
	 *
	 * @return bool
	 */
	final public function hasProperty( $name ) {
		return is_string( $name ) && $this->abstract_reflection && $this->abstract_reflection->hasProperty( $name );
	}

	/**
	 * @param string $name
	 *
	 * @return bool
	 */
	final public function hasConstant( $name ) {
		return is_string( $name ) && $this->abstract_reflection && $this->abstract_reflection->hasConstant( $name );
	}

	/**
	 * @return bool
	 */
	final public function isAnonymous() {
		return $this->abstract_reflection && $this->abstract_reflection->isAnonymous();
	}

	/**
	 * @return bool
	 */
	final public function isClosure() {
		return $this->abstract_reflection && $this->abstract_object_name == 'Closure';
	}

	/**
	 * @return bool
	 */
	final public function isAbstract() {
		return $this->abstract_reflection && $this->abstract_reflection->isAbstract();
	}

	/**
	 * @return bool
	 */
	final public function isInterface() {
		return $this->abstract_reflection && $this->abstract_reflection->isInterface();
	}

	/**
	 * @return bool
	 */
	final public function isTrait() {
		return $this->abstract_reflection && $this->abstract_reflection->isTrait();
	}

	/**
	 * @return bool
	 */
	final public function isFinal() {
		return $this->abstract_reflection && $this->abstract_reflection->isFinal();
	}

	/**
	 * @return bool
	 */
	final public function isInstantiable() {
		return $this->abstract_reflection && $this->abstract_reflection->isInstantiable();
	}

	/**
	 * @param string|object $class
	 *
	 * @return bool
	 */
	final public function isSubclassOf( $class ) {
		if ( $this->abstract_reflection && ( is_string( $class ) || is_object( $class ) ) ) {
			if ( is_string( $class ) && class_exists( $class ) ) {
				$class = is_object( $class ) ? get_class( $class ) : $class;
				return $this->abstract_reflection->isSubclassOf( $class );
			}
		}

		return false;
	}
}
