<?php

namespace FileTrip\WP\Extensions\Core;

use FileTrip\WP\Extensions\Core\Abstracts\ITF_Extension;
use FileTrip\WP\Extensions\Core\Helper\Reflector_Helper;

final class Extension_Loader {


	/**
	 * @var array
	 */
	public static $extension_lists = array();

	/**
	 * @var Extension_Loader
	 */
	private static $instance;

	/**
	 * @var array
	 */
	public static $status_extension = array();

	/**
	 * Extension_Loader constructor.
	 */
	public function __construct() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = $this;
		}
	}

	/**
	 * @return Extension_Loader
	 */
	public static function getInstance() {
		if ( ! isset( self::$instance ) ) {
			return new self();
		}
		return self::$instance;
	}

	/**
	 * @param Extension_Initiator $extension_initializer
	 *
	 * @return bool|Extension_Initiator
	 */
	public function addExtensionsData( Extension_Initiator $extension_initializer ) {
		$name = $extension_initializer->getName();
		$extension_initializer->initLoad();
		if ( is_string( $name ) ) {
			if ( ! isset( self::$extension_lists[ $name ] ) ) {
				self::$status_extension[ $name ] = $extension_initializer;
				foreach ( $extension_initializer->getAvailableExtension() as $key => $val ) {
					/** @noinspection PhpUndefinedMethodInspection */
					self::$extension_lists[ $name ][ $key ] = $val::extensionGetInstance();
				}
			}

			return $extension_initializer;
		}

		return false;
	}

	/**
	 * Inject Extension
	 *
	 * @param string $name
	 * @param string $extension_class
	 * @return string|bool
	 */
	public function injectExtensionTo( $name, $extension_class ) {
		if ( is_string( $extension_class ) && class_exists( $extension_class )
			&& $this->hasExtensions( $name )
			&& self::$status_extension[ $name ]->isInjectable()
			&& is_subclass_of(
				$extension_class,
				'\\FileTrip\\WP\\Extensions\\Core\\Abstracts\\ITF_Extension'
			)
		) {
			$list_extensions_name  = array_keys( self::$extension_lists[ $name ] );
			$list_extensions_class = self::$status_extension[ $name ]->getAvailableExtension();
			$reflector             = new Reflector_Helper( $extension_class );
			/**
			 * @var ITF_Extension
			 */
			$class_name   = $reflector->getName();
			$class_name__ = trim( $class_name, '\\' );
			if ( ! in_array( $class_name__, $list_extensions_class, true ) && ! in_array( $class_name__, $list_extensions_name, true ) ) {
				/** @noinspection PhpUndefinedMethodInspection */
				self::$extension_lists[ $name ][ $class_name__ ] = $class_name::extensionGetInstance();
			}
			return $name;
		}

		return false;
	}

	/**
	 * @param string $name
	 * @param string $selector
	 *
	 * @return mixed
	 */
	public function loadExtension( $name, $selector ) {
		if ( $this->getExtension( $name, $selector ) ) {
			$selector = trim( $selector, '\\' );
			/** @noinspection PhpUndefinedMethodInspection */
			self::$extension_lists[ $name ][ $selector ]->callInit();
			return self::$extension_lists[ $name ];
		}

		return false;
	}

	/**
	 * @param string $name
	 *
	 * @return bool
	 */
	public function hasExtensions( $name ) {
		return ( is_string( $name ) && isset( self::$extension_lists[ $name ] ) );
	}

	/**
	 * @param string $name
	 *
	 * @return bool|array
	 */
	public function getExtensions( $name ) {
		if ( $this->hasExtensions( $name ) ) {
			return self::$extension_lists[ $name ];
		}

		return false;
	}

	/**
	 * @param string $name
	 * @param string $extension_name
	 *
	 * @return bool|ITF_Extension
	 */
	public function getExtension( $name, $extension_name ) {
		if ( ! is_string( $extension_name ) || ! is_string( $name ) ) {
			return false;
		}
		$extension = $this->getExtensions( $name );
		if ( ! empty( $extension[ $extension_name ] ) ) {
			return $extension[ $extension_name ];
		}

		return false;
	}
}
