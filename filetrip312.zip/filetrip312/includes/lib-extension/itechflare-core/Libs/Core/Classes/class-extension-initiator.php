<?php

namespace FileTrip\WP\Extensions\Core;

use FileTrip\WP\Extensions\Core\Helper\File;
use FileTrip\WP\Extensions\Core\Helper\Loader_Once;
use FileTrip\WP\Extensions\Core\Helper\Reflector_Helper;

final class Extension_Initiator {


	/**
	 * @var string
	 */
	protected $extension_directory;

	/**
	 * @var File
	 */
	protected $file_helper;

	/**
	 * @var bool
	 */
	protected $extension_directory_valid;

	/**
	 * @var string
	 */
	protected $name_extension;

	/**
	 * @var bool
	 */
	protected $has_loaded_call;

	/**
	 * @var array
	 */
	protected $available_extension = array();

	/**
	 * @var array
	 */
	protected $invalid_extension = array();

	/**
	 * @var string
	 */
	protected $option_name;

	/**
	 * @var bool
	 */
	protected $injectable;

	/**
	 * Extension_Loader constructor.
	 *
	 * @param string $extension_directory
	 * @param string $name
	 * @param bool   $injectable
	 */
	public function __construct( $extension_directory, $name = null, $injectable = false ) {
		// prevent call __construct
		if ( isset( $this->extension_directory_valid ) ) {
			return;
		}
		$this->extension_directory_valid = false;
		$this->file_helper               = File::getInstance();
		if ( $this->file_helper->isDir( $extension_directory ) && realpath( $extension_directory ) ) {
			$this->setName( $name );
			$this->injectable                = (bool) $injectable;
			$this->extension_directory       = realpath( $extension_directory );
			$this->extension_directory_valid = true;
		}
	}

	/**
	 * @return bool
	 */
	public function isInjectable() {
		return $this->injectable;
	}

	/**
	 * @param string $name
	 */
	public function setName( $name ) {
		if ( is_string( $name ) && ! isset( $this->name_extension ) ) {
			$this->option_name    = 'itf_extension_option_' . md5( $name );
			$this->name_extension = $name;
		}
	}

	/**
	 * @return string
	 */
	public function getOptionName() {
		return $this->option_name;
	}

	/**
	 * @return string
	 */
	public function getName() {
		return $this->name_extension;
	}

	public function getExtensionDirectory() {
		return $this->extension_directory;
	}

	/**
	 * @return bool
	 */
	public function hasCalledInit() {
		return $this->has_loaded_call;
	}

	/**
	 * Load init
	 */
	public function initLoad() {
		if ( ! $this->hasCalledInit() ) {
			$this->has_loaded_call = true;
			if ( $this->extension_directory_valid ) {
				$ext_dir         = $this->getExtensionDirectory();
				$directory_array = $this->file_helper->dirlist(
					$this->getExtensionDirectory(),
					false,
					true
				);

				$key_prefix                   = 'class-';
				$extension_namespace_no_quote = __NAMESPACE__ . '\\Abstracts\\ITF_Extension';
				$extension_namespace          = preg_quote( $extension_namespace_no_quote );
				foreach ( $directory_array as $key => $item ) {
					if ( $item['type'] !== 'd' || empty( $item['files'] ) ) {
						continue;
					}
					$file_key = $key_prefix . $key;
					if ( empty( $item['files'][ "{$file_key}.php" ] ) || $item['files'][ "{$file_key}.php" ]['type'] != 'f' ) {
						continue;
					}

					$file = realpath( "{$ext_dir}/{$key}/{$file_key}.php" );
					if ( ! $file ) {
						continue;
					}

					// load files
					Loader_Once::load( $file );
					// get Contents
					$string          = substr( $this->file_helper->getContents( $file ), 0, 2048 );
					$classname       = str_replace('-', '_', $key);
					$classname_words = explode('_', $classname);

					// Capitalize the first letter of each word
					foreach ( $classname_words as &$word ) {
						$word = ucfirst($word);
					}

					$classname = implode('_', $classname_words);
					// validate
					if ( trim( $string ) == '' || stripos( $string, '<?php' ) !== 0
						|| stripos( $string, $classname ) === false
						|| stripos( $string, 'ITF_Extension' ) == false
					) {
						continue;
					}
					$class = preg_quote( $classname, '/' );
					if ( preg_match( '/class\s+' . $class . '\s+extends\s*\\?' . $extension_namespace . '\s*\{/im', $string )
						|| preg_match( '/use\s+\\\?' . $extension_namespace . '(?:\s+as\s+([a-z][a-z0-9]+))?\s*\;/i', $string, $match )
						   && ! empty( $match[0] )
						   && (
							   ! empty( $match[1] )
							   && preg_match( '/class\s+' . $class . '\s+extends\s+' . preg_quote( $match[1], '/' ) . '\s*\{/im', $string )
							   || preg_match( '/class\s+' . $class . '\s+extends\s*ITF_Extension\s*\{/im', $string )
						   )
					) {
						preg_match( '/namespace\s+(.+)\;/i', $string, $match );
						$class = ! empty( $match[1] ) && trim( $match[1] ) != ''
							? ltrim( $match[1], '\\' ) . '\\' . $classname
							: $key;
						if ( class_exists( $class ) ) {
							/**
							 * @var Reflector_Helper
							 */
							$reflector = new Reflector_Helper( $class );
							if ( $reflector->isSubclassOf( $extension_namespace_no_quote ) ) {
								$this->available_extension[ $key ] = $reflector->getName();
								continue;
							}

							// set invalid
							$this->invalid_extension[ $key ] = $class;
							continue;
						}
						// set invalid
						$this->invalid_extension[ $key ] = $class;
					}
				}

				unset( $directory_array, $string );
			}
		}
	}

	/**
	 * @return array
	 */
	public function getAvailableExtension() {
		return $this->available_extension;
	}

	/**
	 * @return array
	 */
	public function getInvalidExtension() {
		return $this->invalid_extension;
	}

	/**
	 * @return string
	 */
	public function getNonce() {
		static $nonce;

		if ( ! isset( $nonce ) ) {
			$nonce = wp_create_nonce( md5( $this->getName() ) );
		}

		return $nonce;
	}

	/**
	 * @param string $query
	 *
	 * @return bool|false|int
	 */
	public function verifyNonce( $query = '_wpnonce' ) {
		if ( ! is_string( $query ) ) {
			return false;
		}

		$nonce = isset( $_REQUEST[ $query ] ) ? $_REQUEST[ $query ] : false;
		return $nonce ? wp_verify_nonce( $nonce, md5( $this->getName() ) ) : false;
	}

	/**
	 * @return array
	 */
	public function getDataOption() {
		$name    = $this->getOptionName();
		$options = get_option( $name, array() );
		if ( ! is_array( $options ) ) {
			$options = array();
			update_option( $name, $options );
		}

		return $options;
	}
}
