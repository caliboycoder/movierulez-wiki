<?php
/**
 * @internal FileTrip\WP\Extensions\Core\Admin_Menu
 */
if ( ! isset( $this ) || ! class_exists( '\\FileTrip\\WP\\Extensions\\Core\\Admin_Menu' )
	|| ! $this instanceof FileTrip\WP\Extensions\Core\Admin_Menu
) {
	return;
}

/**
 * @var \FileTrip\WP\Extensions\Core\Extension_Loader
 */
$loader         = $this->getExtension_Loader();
$is_core_shown  = $this->isCoreExtensionShown();
$lib_url        = $this->libraryUrl();
$core_extension = $this->getCoreExtension();
?>
<div class="wrap">
	<h1><?php echo $this->getMenuTitle() . ' ' .esc_attr__( 'Extensions', 'itf-plugin' ); ?></h1>
	<br />
	<hr />
	<p>
		<span class="button button-selector button-primary" data-target=".plugin-card"><?php echo esc_attr__( 'All', 'itf-plugin' ); ?></span>
		<?php if ( $is_core_shown && ! empty( $core_extension ) ) : ?>
			<span class="button button-selector" data-target=".core-extension"><?php echo esc_attr__( 'Core Extension', 'itf-plugin' ); ?></span>
			<span class="button button-selector" data-target=".non-core"><?php echo esc_attr__( 'Non Core Extension', 'itf-plugin' ); ?></span>
		<?php endif; ?>
		<span class="button button-selector" data-target=".active-extension"><?php echo esc_attr__( 'Active Extension', 'itf-plugin' ); ?></span>
		<span class="button button-selector" data-target=".inactive-extension"><?php echo esc_attr__( 'Inactive Extension', 'itf-plugin' ); ?></span>
	</p>
	<hr /><br />
	<form id="itf_wp_extensions" method="post">
		<div class="wp-list-table widefat itf_wp-module-install">
			<h2 class="screen-reader-text"><?php sprintf( '%s Module List', $this->getMenuTitle() ); ?></h2>
			<div id="itf_wp-module-list">
				<?php
				$count = 1;
				foreach ( (array) $this->getAllAvailableExtensions() as $extension_name ) {
					$extension = $loader->getExtension( $this->getName(), $extension_name );
					if ( ! $extension || ! $is_core_shown && ! empty( $core_extension ) && in_array( $extension_name, $core_extension, true ) ) {
						continue;
					}

					/**
					 * @var \FileTrip\WP\Extensions\Core\Abstracts\ITF_Extension
					 */
					$icon        = $extension->extensionGetIcon();
					$icon        = trim( $icon ) != '' ? $icon : dirname( $lib_url ) . '/assets/images/icon-unavailable.png';
					$author      = $extension->extensionGetAuthor();
					$author_uri  = $extension->extensionGetAuthorUri();
					$description = $extension->extensionGetDescription();
					if ( trim( $description ) == '' ) {
						$desc        =esc_attr__( 'Description unavailable', 'itf-plugin' );
						$desc       .= str_repeat( ' &nbsp;', ( 123 - strlen( $desc ) ) / 2 );
						$description = '<span style="color: #999;"><em>' . $desc . '</em></span>';
					} else {
						$description  = substr( $description, 0, 120 ) . ( strlen( $description ) < 120 ? '' : ' ...' );
						$description .= strlen( $description ) < 120 ? str_repeat( ' &nbsp;', ( 123 - strlen( $description ) ) / 2 ) : '';
					}

					$extension_uri = $extension->extensionGetUri();
					$extension_uri = $extension_uri != ''
						? '<strong><a target="_blank" title="' . esc_attr__( 'Visit Module URL', 'itf-plugin' ) . "\" href=\"{$extension_uri}\">" .esc_attr__( 'Visit Extension URL', 'itf-plugin' ) . '</a></strong>'
						: '<span style="color:#999;"><em>' .esc_attr__( 'Module URL Unavailable', 'itf-plugin' ) . '</em></span>';
					// classes
					$class  = in_array( $extension_name, $core_extension, true ) ? 'core-extension' : 'non-core';
					$class .= $extension->extensionHasLoaded() ? ' active-extension' : ' inactive-extension';
					$class .= ( $count % 2 ) === 0 ? ' the-even' : ' the-odd';
					$count++;
					?>
					<div class="plugin-card <?php echo $class; ?>">
						<div class="plugin-card-top">
							<div class="name column-name">
								<h3>
									<?php echo $extension->extensionGetName(); ?>
									<img src="<?php echo $icon; ?>" class="extension-icon plugin-icon" alt="<?php $extension->extensionGetName(); ?>">
								</h3>
							</div>
							<div class="action-links">
								<ul class="plugin-action-buttons">
									<?php if ( in_array( $extension_name, $core_extension, true ) ) { ?>
										<li><span class="install-now button disabled" disabled="disabled" data-slug="<?php echo $extension_name; ?>" aria-label="<?php esc_attr__( 'Activate', 'itf-plugin' ) . ' ' . $extension->extensionGetName() . ' ' . $extension->extensionGetVersion(); ?>" data-name="<?php $extension->extensionGetName() . ' ' . $extension->extensionGetVersion(); ?>"><?php echo esc_attr__( 'Core Activated', 'itf-plugin' ); ?></span></li>
									<?php } else { ?>
										<?php if ( $extension->extensionHasLoaded() ) { ?>
											<li><a class="install-now button" data-slug="<?php echo esc_attr( $extension_name ); ?>" href="<?php menu_page_url( $this->getSlugExtension() ); ?>&amp;extension_action=deactivate&amp;extension=<?php echo esc_attr( str_replace( '\\', '-', $extension_name ) ); ?>&amp;_wpnonce=<?php echo $this->getNonce(); ?>" aria-label="<?php esc_attr__( 'Activate', 'itf-plugin' ) . ' ' . $extension->extensionGetName() . ' ' . $extension->extensionGetVersion(); ?>" data-name="<?php $extension->extensionGetName() . ' ' . $extension->extensionGetVersion(); ?>"><?php echo esc_attr__( 'Deactivate', 'itf-plugin' ); ?></a></li>
										<?php } else { ?>
											<li><a class="install-now button button-primary" data-slug="<?php echo esc_attr( $extension_name ); ?>" href="<?php menu_page_url( $this->getSlugExtension() ); ?>&amp;extension_action=activate&amp;extension=<?php echo str_replace( '\\', '-', $extension_name ); ?>&amp;_wpnonce=<?php echo $this->getNonce(); ?>" aria-label="<?php esc_attr__( 'Deactivate', 'itf-plugin' ) . ' ' . $extension->extensionGetName() . ' ' . $extension->extensionGetVersion(); ?>" data-name="<?php $extension->extensionGetName() . ' ' . $extension->extensionGetVersion(); ?>"><?php echo esc_attr__( 'Activate', 'itf-plugin' ); ?></a></li>
										<?php } ?>
									<?php } ?>
								</ul>
							</div>
							<div class="desc column-description">
								<p><?php echo $description; ?></p>
								<p class="authors"><cite>By
										<?php if ( ! empty( $author ) ) { ?>
										<a href="<?php echo $author_uri; ?>" target="_blank"><?php echo $author; ?></a>
										<?php } else { ?>
											<span style="color:#999"><em><?php echo esc_attr__( 'Unknown Author', 'itf-plugin' ); ?></em></span>
										<?php } ?>
									</cite>
								</p>
							</div>
						</div>
						<div class="plugin-card-bottom">
							<div class="vers column-rating">
								<div class="star-rating">
									<strong><?php echo esc_attr__( 'Version :', 'itf-plugin' ); ?></strong> <?php echo $extension->extensionGetVersion(); ?>
								</div>
							</div>
							<div class="column-updated">
								<?php echo $extension_uri; ?>
							</div>
						</div>
					</div>
					<?php
				}
				?>
			</div>
		</div>
	</form>
</div>
<?php
