<?php

namespace FileTrip\WP\Extensions;

use FileTrip\WP\Extensions\Core\Admin_Menu;
use FileTrip\WP\Extensions\Core\Extension_Initiator;

/**
 * Class ITF_Core
 *
 * @package FileTrip\WP\Plugin\FileTrip
 */
final class ITF_Core {


	/**
	 * Version
	 */
	const VERSION = \Filetrip_Constants::ITF_CORE_EXTENSION_VER;

	/**
	 * Plugin Name
	 */
	const PLUGIN_NAME = \Filetrip_Constants::PLUGIN_NAME;

	/**
	 * Short name
	 */
	const SHORT_NAME = 'ITF_Core';

	/**
	 * @var ITF_Core
	 */
	protected static $instance;

	/**
	 * @var Admin_Menu
	 */
	protected static $admin_menu;

	/**
	 * @var Extension_Initiator
	 */
	protected $extension_initializer;

	// add some core extension directory name here
	private static $core_extension = array(
		'Support_Center_Ext',
	);

	/**
	 * @var array
	 */
	private static $prior_extension = array();

	/**
	 * @var string
	 */
	protected $capability = 'edit_posts';

	/**
	 * Core constructor.
	 */
	public function __construct() {
		if ( ! isset( self::$instance ) ) {
			self::$instance              = $this;
			$c                           = $this;
			$this->extension_initializer = new Extension_Initiator(
				FILETRIP_EXTENSION_DIRECTORY,
				self::SHORT_NAME,
				true // injectable
			);

			self::$admin_menu = new Admin_Menu( $this->extension_initializer );

			/**
			 * Admin Menu Hooks
			 */
			add_action(
				'itf_filetrip_admin_loaded_extension',
				function ( $itf ) use ( $c ) {
					$c->showAdmin();
				},
				1
			);

			add_action(
				'itf_filetrip_admin_loaded_extension',
				function ( $itf ) use ( $c ) {
					// doing before extension loaded
					do_action( 'itf_before_core_loaded', $itf );
					$c::$admin_menu->renderAdmin_Menu( 90 );
					do_action( 'itf_after_core_loaded', $itf );
				},
				40
			);
		}
	}


	/**
	 * Add Extension
	 *
	 * @param string $class_name
	 * @return bool|string
	 */
	public function addExtension( $class_name ) {
		error_log($class_name);
		return self::$admin_menu
			->getExtension_Loader()
			->injectExtensionTo(
				self::SHORT_NAME,
				$class_name
			);
	}

	/**
	 * Current Core Url
	 *
	 * @return string
	 */
	public static function flareCoreUrl() {
		static $url;
		if ( ! $url ) {
			$url = plugins_url( '', dirname( __DIR__ ) );
		}
		return $url;
	}

	/**
	 * @return ITF_Core
	 */
	protected function showAdmin() {
		static $showed;
		$instance = static::getInstance();
		if ( $showed ) {
			return $instance;
		}

		$showed = true;
		$instance::$admin_menu->setCoreExtensions( static::$core_extension );
		$instance::$admin_menu->setPriorExtension( static::$prior_extension );
		$instance::$admin_menu->setCapability( $instance->capability );
		$instance::$admin_menu->setMenuTitle( static::PLUGIN_NAME );
		$instance::$admin_menu->setPageTitle(
			static::PLUGIN_NAME . ' Extensions'
		);

		// Add Menu Page
		$instance::$admin_menu->setAdmin_MenuPage(
			function () {
				require __DIR__ . '/Screens/admin-menu-page.php';
			}
		);
		$instance::$admin_menu->initExtensions();
		return $instance;
	}

	/**
	 * @return ITF_Core
	 */
	public static function getInstance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Get version
	 *
	 * @return string
	 */
	public function getVersion() {
		$instance = self::getInstance();
		return $instance::VERSION;
	}

	/**
	 * Get Plugin Name
	 *
	 * @return string
	 */
	public function getPluginName() {
		$instance = self::getInstance();
		return $instance::PLUGIN_NAME;
	}

	/**
	 * @return string
	 */
	public static function getName() {
		$instance = self::getInstance();
		return $instance::$admin_menu->getName();
	}

	/**
	 * @return string
	 */
	public static function getShortName() {
		$instance = self::getInstance();
		return $instance::SHORT_NAME;
	}

	/**
	 * @return string
	 */
	public static function getSlugExtension() {
		$instance = self::getInstance();
		return $instance::$admin_menu->getSlugExtension();
	}

	/**
	 * @return string
	 */
	public static function getSlug() {
		$instance = self::getInstance();
		return $instance::$admin_menu->getSlug();
	}

	/**
	 * @return string
	 */
	public static function getPageTitle() {
		$instance = self::getInstance();
		return $instance::$admin_menu->getPageTitle();
	}

	/**
	 * @return string
	 */
	public static function getMenuTitle() {
		$instance = self::getInstance();
		return $instance::$admin_menu->getMenuTitle();
	}

	/**
	 * @return string
	 */
	public static function getCapability() {
		$instance = self::getInstance();
		return $instance::$admin_menu->getCapability();
	}
	/**
	 * @param string $name
	 *
	 * @return mixed
	 */
	public static function getExtension( $name ) {
		$instance = self::getInstance();
		return $instance::$admin_menu->getExtension( $name );
	}

	/**
	 * @return array
	 */
	public static function getAllAvailableExtensions() {
		$instance = self::getInstance();
		return $instance::$admin_menu->getAllActiveExtensions();
	}

	/**
	 * @return array
	 */
	public static function getAllActiveExtensions() {
		$instance = self::getInstance();
		return $instance::$admin_menu->getAllActiveExtensions();
	}

	/**
	 * @return array
	 */
	public static function getDBActiveExtensions() {
		$instance = self::getInstance();
		return $instance::$admin_menu->getDBActiveExtensions();
	}

	/**
	 * @return string
	 */
	public static function getNonce() {
		$instance = self::getInstance();
		return $instance::$admin_menu->getNonce();
	}

	/**
	 * @return bool|false|int
	 */
	public static function verifyNonce() {
		$instance = self::getInstance();
		return $instance::$admin_menu->verifyNonce();
	}

	/**
	 * Add Sub Menu Page
	 *
	 * @param string   $page_title
	 * @param string   $menu_title
	 * @param string   $capability
	 * @param string   $slug
	 * @param callable $fn
	 * @param int      $priority
	 *
	 * @return string|bool
	 */
	public static function addSubMenuPage(
		$page_title,
		$menu_title,
		$capability,
		$slug,
		$fn,
		$priority = 0
	) {
		$instance = self::getInstance();
		return $instance::$admin_menu
			->addSubMenuPage(
				$page_title,
				$menu_title,
				$capability,
				$slug,
				$fn,
				$priority
			);
	}

	/**
	 * Get Extension Loader Object
	 *
	 * @return Core\Extension_Loader
	 */
	public static function getExtension_Loader() {
		$instance = self::getInstance();
		return $instance::$admin_menu->getExtension_Loader();
	}
}
