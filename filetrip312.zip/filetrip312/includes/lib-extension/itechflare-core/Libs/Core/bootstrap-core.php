<?php
/**
 * PSR0 Auto Loader
 */
return spl_autoload_register('auto_loader');

function auto_loader( $class_name ) {
	$base_dir   = str_replace( '\\', '/', __DIR__ ) . '/Classes/';
	$name_space = 'FileTrip\\WP\\Extensions\\Core';
	$class_name = ltrim( $class_name, '\\' );
	// doing check
	if ( class_exists( $class_name ) || stripos( $class_name, $name_space ) !== 0 ) {
		return;
	}
	$class_name      = substr( $class_name, strlen( $name_space ) );
	$class_name      = str_replace( '\\', '/', ltrim( $class_name, '\\' ) );
	$path_parts      = pathinfo($class_name);
	$class_name      = strtolower(str_replace('_', '-', $path_parts['basename']));
	$class_name      = 'class-' . $class_name;
	$class_directory = str_replace( '.', '', $path_parts['dirname'] );
	$class_directory = $class_directory === '' ? $class_directory : $class_directory . '/';
	$filename        = $base_dir . $class_directory . $class_name . '.php';
	if ( file_exists( $filename ) ) {
		/** @noinspection PhpIncludeInspection */
		require_once $filename;
	}
}
