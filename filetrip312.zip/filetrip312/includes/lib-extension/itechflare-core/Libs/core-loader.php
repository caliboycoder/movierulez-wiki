<?php
/**
 * @todo completion
 */
if ( ! defined( 'ABSPATH' ) ) {
	return;
}

// require Bootstrap Core
require_once __DIR__ . '/Core/bootstrap-core.php';
require_once __DIR__ . '/Core/class-itf-core.php';
require_once __DIR__ . '/Core/core-functions.php';
