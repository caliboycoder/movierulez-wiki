##ITECHFLARE CORE

`plugins for itechflare core`

This is priority development to implement as theme plugins

