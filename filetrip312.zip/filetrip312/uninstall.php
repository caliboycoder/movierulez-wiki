<?php

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	return;
}

if ( ! current_user_can( 'activate_plugins' ) ) {
	return;
}

// Don't activate on old versions of WordPress
global $wp_version;

if ( version_compare( $wp_version, FILETRIP_REQUIRED_WP_VERSION, '<' ) ) {
	return;
}

if ( ! defined( 'FILETRIP_PLUGIN_DIR_PATH' ) ) {
	define( 'FILETRIP_PLUGIN_DIR_PATH', plugin_dir_path( __FILE__ ) );
}

require_once FILETRIP_PLUGIN_DIR_PATH . 'includes/lib-extension/classes/class-filetrip-constants.php';

// Remove all the options
foreach ( array( 'filetrip_settings', 'filetrip_mime_setting', 'filetrip_dropbox_setting', 'filetrip_google_drive_setting', 'filetrip_ftp_setting', 'filetrip_bkp_enable_support', 'filetrip_bkp_plugin_version', 'filetrip_bkp_path', 'filetrip_bkp_default_path', 'filetrip_bkp_upsell' ) as $filetrip_option ) {
	delete_option( $filetrip_option );
}

// Delete all transients
foreach ( array( 'filetrip_error_transient' ) as $filetrip_transient ) {
	delete_transient( $filetrip_transient );
}
