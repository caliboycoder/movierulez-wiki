# Issue: Unable to install - repository not found on termux window.
## Solution:

### Copy command and past in termux

```bash
termux-change-repo
```


#### 1. select all repository using down aroow and space bar


 <img src="https://cdn.discordapp.com/attachments/913442509345157150/921795479166144583/IMG_20211218_211931.jpg" alt="drawing" style="width:200px;"/>.

 #### 2. click ok after select all repository


  <img src="https://cdn.discordapp.com/attachments/913442509345157150/921795479166144583/IMG_20211218_211931.jpg" alt="drawing" style="width:200px;"/>



 #### 3. if you getting error like this


  <img src="https://cdn.discordapp.com/attachments/913442509345157150/921795478046249030/IMG_20211218_213420.jpg" alt="drawing" style="width:200px;"/>

#### enter `N` for all


### follow all [old](https://github.com/dhruv-2015/JTVServer/blob/master/README.md#lets-get-started "old") command to install server
