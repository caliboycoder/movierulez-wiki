<p align='center'><img src="https://ik.imagekit.io/techiesneh/tv_logo/jtv-plus_TMaGGk6N0.png" width="120"></p>

<!--
* Copyright 2021-2023 SnehTV, Inc.
* Licensed under MIT (https://github.com/mitthu786/TS-JioTV/blob/main/LICENSE)
* Created By : TechieSneh
* Re-Create By : Maxmentor
-->

<h4 align='center'>📺 The PHP Script For Grab Streaming Links and Play it ,<br> This Works Only on Android & Android TV
Through LocalHost <br><br>🌟 Star This Repository Before Forking 😎<br>Don't Edit This Script
😈</h4>
<br>

<h3>♻️ JOIN FOR UPDATES :</h3>

- JOIN TELEGRAM CHANNEL
- https://t.me/maxmentor

<h3>😇 SCRIPT FEATURES :</h3>

- New UI & Design
- Dropdown Filters Added
- Will Works In All Qualities
- Multi Audio Stream Support
- Web Play with Quality Change Supports
- Works on Mobile, AndroidTV or PC Browser Perfect

<h3>💖 PLAYER FEATURES :</h3>

- Search Feature Added<br>

1. 🔍 SEARCH BY CHANNEL NAME

```
e.g.  Sony,Zee,Star ...
```

2. 🔍 SEARCH BY GENRE

```
e.g.  Entertainment,Kids,Movies,Music ...
```

3. 🔍 SEARCH BY LANGUAGE

```
e.g.  Hindi,Tamil,Kannada,Odia ...
```

<br>

<h3>📸 Screen Shots : </h3>

<img src="https://i.ibb.co/ZVFLtHQ/a1.png" width="400" height="200"><br>
<img src="https://i.ibb.co/jRJxqTZ/s2.png" width="400" height="200">

<br>

<h2>🍁 HOW TO USE : </h2>

- <br>
• Install KsWeb App https://dl1.apkhome.net/2019/6/KSWEB-3.93%20Pro.apk <br>
• Extrac All Files In Htdocs Folder.<br>
• Open Ksweb app & Goto: http://localhost:8080<br>

• First Login With Jio Account , After Jogin You can paly All channles.

*Note: SonyLiv Channels Working Only In Live Server. 
 suggest : https://onohosting.com/
<!--
* Copyright 2021-2023 SnehTV, Inc.
* Licensed under MIT (https://github.com/mitthu786/TS-JioTV/blob/main/LICENSE)
* Created By : TechieSneh
-->

### 😛 GENERATE CREDS.JSON (OTP USERS):

1. ✍️ FOR SSO TOKEN : [JioLogin](http://jiologin.unaux.com)
2. For This You Need JioID Number and Password
3. You Can Also get Data with OTP

- `user` = Username / Mobile No.
- `pass` = Password




<!-- DO NOT REMOVE THIS CREDIT -->
@maxmentor
🚸 WARNINGS :

This is Just For Educational Purpose

DO NOT Sell this Script, This is 💯% Free

Join Our Telegram : https://t.me/maxmentor
