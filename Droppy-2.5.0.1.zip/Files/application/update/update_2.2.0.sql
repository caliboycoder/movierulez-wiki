ALTER TABLE droppy_downloads MODIFY `ip` VARCHAR(100);
ALTER TABLE droppy_downloads MODIFY `email` VARCHAR(100);