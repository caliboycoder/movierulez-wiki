
<p align="center"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcScPSNefEI0l3U47cxheilqsKlDMi2k7A7mYA&usqp=CAU" width="180" height="100"></p>

<h1 align='center'>✯ TATAPLAY ✯</h1>

<!-- DO NOT EDIT FILE AND ADD YOU NAME HERE AND PUBLISH -->
<!-- © 2021 TechieSneh -->

<h4 align='center'>📺 The PHP Script For Grabb Streaming Links and Play it , This Works Only on Android & Android TV Through LocalHost <br><br>🌟 Star This Repositry Befor Copying 😎<br>😠 Don't Remove Credits<br> 😈 Don't Edit This Script 😈<br> 😍😍Script Still work if your Account is Suspended 😍😍<br> 🫠 You can Watch only that channels that are subscribe to your account 🫠<br>Put Your Own Credentials In This Script <br> 🙂 TataPlay Account required 🙂</h4>
<br>

<h2>😇 Features :</h2>

- HQ Streaming Free of Cost <br>
- Will Works In ALL Qualities
- Web Play Supports
- Works on Phone or PC Browser Perfect


<br>
<h2>🍁 How To Use : </h2>

#### ♢ Method 1 :

• First Download This Application<br>
 - KSWEB PRO ( Php Web Server ) <br>

  ```py
  
https://dl1.apkhome.net/2019/6/KSWEB-3.93%20Pro.apk

  ```
  
  ```py

https://apkcow.com/ksweb-server-php-mysql-mod-apk/download/

  ```

• Then Download This Zip Files<br>
 - TataPlay Zip <br> ( https://github.com/dnyaneshpainjane/TataPlay-web/archive/refs/heads/main.zip ) <br>

• Locate & Extract all Files in LocalHost (Htdocs) Root Folder <br>
• Open KSWEB App & Start The Server <br>
• Go to following link using browser <br>

```py
http://localhost:8080/TataPlay/
```
• Put Your login details <br>

• Click login You Will See all subscribed Channels . <br>
• Click On Channel and Play <br>


IF THERE IS ERROR IN PLAYING VIDEO FOLLOW BELOW BLOG <br>
(https://appuals.com/fix-error-loading-media-file-not-played-chrome/#:~:text=The%20issue%20mainly%20occurs%20when,use%20the%20H264%20video%20codec.) <br>
#### ♢ Method 2 :(NOT WORKING)

• In Tivimate or OTT Navigator Player Put Links Format Like Below

  ```py
http://localhost:8080/TataPlay/app/playlist.php
  ```
  
   • Now Enjoy with your TataPlay Channels.</b><br>

<br>
 

<h2>🚸 Warnings :</h2>

- This is Just For Educational Purpose
- DO NOT Sell this Script, This is 💯% Free
- Follow me for more such Tricks
(https://github.com/dnyaneshpainjane)
<br>


---
<h4 align='center'>© 2022 Dnyanesh </h4>

<!-- DO NOT REMOVE THIS CREDIT 🤬 🤬 -->
