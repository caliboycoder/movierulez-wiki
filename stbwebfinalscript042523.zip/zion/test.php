<html>
<head>
<link rel="stylesheet" href="https://cdn.plyr.io/3.5.6/plyr.css" />
<script src="https://cdn.plyr.io/3.5.6/plyr.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/plyr/3.7.3/plyr.min.js"></script>
<script src="https://cdn.jsdelivr.net/hls.js/latest/hls.js"></script>
</head>
<body>
<div id="player">
 <video title="<?php echo $_REQUEST["q"]; ?>" preload="none" id="video" controls="controls" autoplay controls crossorigin style="width:100%;height:100%;"></video>
</div>
<script>
const controls =
[
    'play-large', 
    'play', 
    'fast-forward', 
    'progress', 
    'mute', 
    'volume', 
    'captions', 
    'settings', 
    'pip', 
    'airplay', 
    'fullscreen'
];
const player = new Plyr('#video',{controls});

setTimeout(videovisible, 4000)

function videovisible() {
    document.getElementById('loading').style.display = 'none'
}
var url="https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8";

var video = document.getElementById('video');
 if (Hls.isSupported()) {
    var hls = new Hls();
    hls.loadSource(url);
    hls.attachMedia(video);
    hls.on(Hls.Events.MANIFEST_PARSED, function() {     
       video.play();
    });
  }
  else if (video.canPlayType('application/vnd.apple.mpegurl')) {
    video.src = url;
    video.addEventListener('loadedmetadata', function() {
    video.play();
    });
  }
</script>
</body>
</html>
